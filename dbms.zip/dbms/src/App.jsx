import Navbar from "./components/Navbar"
import Query from "./components/Query"

const App = () => {
  return (
    <>
    <Navbar /> 
    <Query />
    </>
  )

}

export default App